All-In-One Agent Support files

Here you'll find the init scripts and supplemental files used by the
Puppetlabs All-In-One Agent packages built with
https://github.com/puppetlabs/puppet-agent
