module MCollective
  module Logger
    require "mcollective/logger/base"
  end
end
