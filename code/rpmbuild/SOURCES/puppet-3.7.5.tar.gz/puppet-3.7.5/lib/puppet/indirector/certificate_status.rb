require 'puppet/indirector'

class Puppet::Indirector::CertificateStatus
end
