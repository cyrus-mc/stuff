require 'puppet/application/indirection_base'

class Puppet::Application::Catalog < Puppet::Application::IndirectionBase
end
