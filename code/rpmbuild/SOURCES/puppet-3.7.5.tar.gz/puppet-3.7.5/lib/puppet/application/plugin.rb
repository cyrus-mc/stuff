require 'puppet/application/face_base'
class Puppet::Application::Plugin < Puppet::Application::FaceBase
end
